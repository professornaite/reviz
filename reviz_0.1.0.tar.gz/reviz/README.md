# reviz

Visualize relationships between variables.

## Installation

```r
# Install from GitHub (development version)
install.packages("devtools")  # if needed
devtools::install_github(c("professornaite/critstats","professornaite/reviz"))

library(reviz)
library(ggplot2)
library(critstats)

launch_reviz()

